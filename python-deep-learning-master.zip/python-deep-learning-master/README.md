# python-deep-learning
python deep learning notebooks

I am using python to visualize data and learn from it.

5. I built a deep learning classifier to predict the flower types based on features (deep learning circle chasing.ipynb)
4. I built a deep learning regressor to track the perimeters of a circle (deep learning circle chasing.ipynb)
3. I applied gradient boost to predict death trends for three states (time series covid 19.ipynb)
2. I applied linear regression and gradient boost to predict the morality rate trends (time series with machine learning.ipynb)
1. I applied deep learning to predict mpg based in hp, weight, displacement, and gears (linear regressor mpg and horse power.ipynb)


